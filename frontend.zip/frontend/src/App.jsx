function App() {

  return (
    <>
      <div>
<h1>Ez az oldal az App modult jeleniti meg</h1>
      </div>
    </>
  )
}

export default App
